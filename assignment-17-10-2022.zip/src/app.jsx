import {BrowserRouter, NavLink, Route, Routes} from "react-router-dom";
import data from "../src/data.json";
import DetailsComp from "./details/details.component";
function App(){
    return <div>
        <h1>List of Heroes</h1>
        <BrowserRouter>
        {
            data.heroes.map((val,idx)=>{
                return <ul>
                    <li>
                        <NavLink to = {"/details/"+val.id}>{val.name}</NavLink>
                    </li>
                </ul>
            })
        }
        <Routes>
            <Route path="/details" element={<DetailsComp/>}></Route>
            <Route path="/details/:hid" element={<DetailsComp/>}></Route>
        </Routes>
        </BrowserRouter>
    </div>
}

export default App;
