import { useParams } from "react-router-dom";
import data from "../data.json"


function DetailsComp(){
    let params =useParams()
    let hid=params.hid;
    return <div>
        <h1> Details</h1>
        {data.heroes.map((val,idx)=>{
            if(hid===val.id){
            return <div>
                
                     <li>Name:{val.name} </li>
                     <h3>Powerstats</h3>
                     <ul>
                     <li>Intelligence:{val.powerstats.intelligence} </li>
                     <li>Strength:{val.powerstats.strength} </li>
                     <li>:{val.powerstats.speed} </li>
                     <li>:{val.powerstats.durability} </li>
                     <li>:{val.powerstats.power} </li>
                     <li>:{val.powerstats.combat} </li>
                    </ul> 
                    <h3>Biography:</h3>
                        <ul>
                            <li>Full Name: {val.biography["full-name"]}</li>
                            <li>Place of Birth:{val.biography["place-of-birth"]}</li>
                            <li>Publisher:{val.biography.publisher}</li>
                            <li>Release Date:{val.biography.earning}</li>
                            <li>Budget:{val.biography.budget}</li>
                            </ul>
                        
                        <h3>Appearance:</h3> 
                        <ul>
                            <li>Gender: {val.appearance.gender}</li>
                            <li>Race:{val.appearance.race}</li>
                            <li>Height:{val.appearance.height}</li>
                            <li>Weight:{val.appearance.weight}</li>
                            <li>Eyecolour:{val.appearance["eye-color"]}</li>
                            <li>Hair-colour:{val.appearance["hair-color"]}</li>
                             </ul>
                             
                        <h3>Work:</h3>
                        <ul>
                        <li>Weight:{val.work.occupation}</li>
                        <li>Base:{val.work.base}</li>
                         </ul>  
                           

                    
                        
                    
                
                </div>
      }  
      })}
    </div>
}
export default DetailsComp