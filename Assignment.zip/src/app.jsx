import Users from "./user.component";

let App = ()=>{
    return <div>
        <h1>Avenger Stores</h1>
        <Users/>
    </div>
};
export default App