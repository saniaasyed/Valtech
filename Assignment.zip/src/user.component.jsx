import { useEffect } from "react"
import axios from "axios";
import { useState } from "react";

var total=0;
let Users = ()=>{
    let [hero, setHeroes] = useState([]);
    let [qty,getQty] = useState({qty:0});
    let [nproduct,setCart]=useState({id:'',hero:'',name:'',price:'',instock:true})
    
 
    let refresh = ()=>{
        axios.get("http://localhost:2525/data").then(res => {
            setHeroes(res.data);
        })
    }

    let clickHandler=(evt)=>{
        getQty({...qty, qty: Number(evt.target.value)})
    }

    let addCart=(pid)=>{
        axios.get("http://localhost:2525/edit/"+pid).then(res=> {
            setCart(res.data);
            total+=qty*qty*res.data.price;
        })
    }
 
    useEffect(function(){
       refresh();
    },[]);
 
    
    return <div className="bigcart" style={{margin : "50px" }}>

    <div className="shop">

        {hero.map((hero,idx)=>{

            return <div className="box">
             <div className="products">
             Hero : {hero.hero}
             <br />
             Name : {hero.name}
             <br />
             Price : {hero.price}
             <br />

             <label htmlFor="" className="qty">Quantity <br />
             <input type="number" onInput={(evt)=>clickHandler(evt)}/>
             </label>
             <button onClick={()=>addCart(hero._id)}>Add to cart</button>
             </div></div>

        })}

        </div>
        <div className="rightbox">
        <h2>Products</h2>
        <ul>
            <li>Hero:{nproduct.hero}</li>
            <li>Price:{nproduct.price}</li>
            <li>Quantity:{qty.qty}</li>
        </ul>
        <h3 style={{marginLeft:20}}>Total:{nproduct.price*qty.qty}</h3>
        </div>
        

   

</div>



}
 
export default Users 
 