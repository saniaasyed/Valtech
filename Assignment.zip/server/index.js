const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
let errorHandler = require("./utils").errorHandler;
const config = require("./config.json");

let app = express();
let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;
let port = process.env.PORT || config.port;

let Cart = mongoose.model("Cart",Schema({
    id : ObjectId,
    hero : String,
    name : String,
    price : String,
    instock : Boolean
}));

let dbstring = `mongodb+srv://${config.dbuser}:${config.password}@cluster0.xsla9iq.mongodb.net/${config.dbname}?retryWrites=true&w=majority`;
mongoose.connect(dbstring)
.then(res=>console.log("DB Connected"))
.catch(error=>errorHandler);

app.use(express.static(__dirname+"/public"));
app.use(express.json());
app.use(cors());
//read
app.get("/data", (req, res)=>{
    Cart.find().then(dbres=>res.json(dbres))
});
setTimeout(function(){
 
},2000);
 
//create
// app.post("/data", (req, res)=>{
//     let hero = new Cart(req.body);
//     console.log(req.body);
//     cart.save()
//     .then(dbres=>{
//         res.send({ message : "hero added to list"})
//         console.log("db updated")
//     })
//     .catch(err=>errorHandler);
// });
//update
// app.post("/update/:hid", (req, res)=>{
//     console.log("update request recived")
//    Cart.findByIdAndUpdate({_id : req.params.hid})
//   .then(dbRes=>{
//     console.log(dbRes);
//         dbRes.title = req.body.title;
//         dbRes.firstname = req.body.firstname;
//         dbRes.lastname = req.body.lastname;
//         dbRes.save().then(updateRes=>res.send({ message : "hero info updated"} ))
//   })
//   .catch(error=>errorHandler);
// })

// read-update
app.get("/edit/:heroid", (req, res)=>{
    Cart.findById({ _id : req.params.heroid }).then(dbres => {
        res.send(dbres)
    })
})

//delete
// app.delete("/delete/:hid",(req, res)=>{
//     Cart.findByIdAndDelete({ _id : req.params.hid })
//     .then(dbRes => res.send({ message : "hero deleted", cart : dbRes.title}))
// });
  

app.listen(port,config.host,errorHandler);
console.log(`server is now ready on ${config.host}:${port}`)
