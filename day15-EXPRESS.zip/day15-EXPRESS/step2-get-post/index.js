const express = require("express");

let app  = express();

app.use(express.urlencoded({extended:true}));

let herolist = [];

app.get("/",(req,res)=>{
    res.render("home.ejs",{
        compname:"Valtech",
        herolist
    })
})

app.post("/",(req,res)=>{
    // console.log("post request recieved")
    // console.log(req.body.nhero);
    herolist.push(req.body.nhero);
    // console.log(herolist);
    res.redirect("/");
    res.end();

})

app.listen(5000,"localhost",(err)=>{
    if(err)console.log("Error" ,err);
    else console.log("Server is now live on local host 5000")
})