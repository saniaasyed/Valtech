const express = require("express");

let app = express();
var port = process.env.PORT || 6000;


console.log(port);

//app.set("views,templates");
//app.set("view","engine","ejs")
app.use(function(req,res,next){
    console.log("Custom middlewear",req.url)
})

function myfun(){
    console.log("get for homepage received")
}
//routes
app.get("/",myfun,(req,res)=>{
    // res.sendFile(__dirname+"/public/index.html")
    // res.render("index.ejs",{compname:"Valtech",message:"Welcome to life"});
    res.render("index.pug",{compname:"Valtech"});
    
});

app.get("/about",(req,res)=>{
    // res.sendFile(__dirname+"/public/about.html")
    // res.render("about.ejs",{compname:"Valtech"});
    res.render("about.pug",{compname:"Valtech"});
});

app.get("/contact",(req,res)=>{
    // res.sendFile(__dirname+"/public/contact.html")
    //res.render("contact.ejs",{compname:"Valtech"});
    res.render("contact.pug",{compname:"Valtech"});
});




app.listen(port,"localhost",function(error){
    if(error){
        console.log("Error",error)
    }else{
        console.log(`server is now live on localhost: ${port}`)
    }
});