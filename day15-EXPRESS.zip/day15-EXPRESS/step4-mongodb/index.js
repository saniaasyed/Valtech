const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
let url ="mongodb+srv://admin:hS6WnjnSW3CjBibi@cluster0.xsla9iq.mongodb.net/valtechdb?retryWrites=true&w=majority"
let app = express();

let Schema = mongoose.Schema;

let ObjectId = Schema.ObjectId;

let Hero = mongoose.model("Hero", Schema({
    id : ObjectId,
    title: String,
    firstname: String,
    lastname: String
}));

mongoose.connect(url)
.then(function(){
    console.log("db connected")
})

.catch(function(err){
    console.log("Error",err)
})

app.get("/",function(req,res){
    Hero.find().then(dbres=>{
        res.json(dbres)
    })
})

//mongodb+srv://admin:hS6WnjnSW3CjBibi@cluster0.xsla9iq.mongodb.net/?retryWrites=true&w=majority

app.listen(8080,"localhost",function(){

})